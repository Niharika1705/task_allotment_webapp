import { useState, useEffect } from "react";
import "../Dashboard.css";
import Navbar from "../components/Navbar";
import TaskCard from "../components/TaskCard";
import TaskForm from "../components/TaskForm";

function AdminDashboard() {
  const [tasks, setTasks] = useState(() => {
  const savedTasks = localStorage.getItem("tasks");

  return savedTasks
    ? JSON.parse(savedTasks)
    : [
        { title: "Login Page", status: "In Progress" },
        { title: "Dashboard UI", status: "Completed" },
      ];
});
useEffect(() => {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}, [tasks]);

  const addTask = (taskName) => {
    setTasks([
      ...tasks,
      { title: taskName, status: "Not Started" },
    ]);
  };

  return (
    <div className="dashboard">
      <Navbar />

      <h1>Admin Panel</h1>

      <TaskForm addTask={addTask} />

      <h2>Assigned Tasks</h2>

      {tasks.map((task, index) => (
        <TaskCard
          key={index}
          title={task.title}
          status={task.status}
        />
      ))}
    </div>
  );
}

export default AdminDashboard;