import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../App.css";
function Login() {
  const navigate = useNavigate();
  const [role, setRole] = useState("admin");

  return (
    <div className="login-container">
      <div className="login-card">
        <h1>Task Allotment System</h1>

        <input
          type="email"
          placeholder="Enter Email"
        />

        <input
          type="password"
          
          placeholder="Enter Password"
        />
        <select
  value={role}
  onChange={(e) => setRole(e.target.value)}
>
  <option value="admin">Admin</option>
  <option value="trainee">Trainee</option>
</select>

<br /><br />

        <button
  onClick={() => {
    if (role === "admin") {
      navigate("/admin");
    } else {
      navigate("/trainee");
    }
  }}
>
  Login
</button>
      </div>
    </div>
  );
}

export default Login;