import "../Dashboard.css";
import Navbar from "../components/Navbar";
import TaskCard from "../components/TaskCard";
import StatusRequestForm from "../components/StatusRequestForm";

function TraineeDashboard() {
  const tasks = JSON.parse(localStorage.getItem("tasks")) || [];

  return (
    <div className="dashboard">
      <Navbar />

      <h1>My Tasks</h1>

      <h2>My Tasks</h2>

      {tasks.map((task, index) => (
        <TaskCard
          key={index}
          title={task.title}
          status={task.status}
        />
      ))}

      <StatusRequestForm />
    </div>
  );
}

export default TraineeDashboard;