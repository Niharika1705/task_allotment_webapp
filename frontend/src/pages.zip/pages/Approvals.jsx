import "../Dashboard.css";
import Navbar from "../components/Navbar";

function Approvals() {
  return (
    <div className="dashboard">
      <Navbar />

      <h1>Approval Requests</h1>

      <div className="task-card">
        <h3>Login Page</h3>
        <p>Requested By: Rahul</p>
        <p>Status: Pending Approval</p>

       <button className="approve-btn">Approve</button>
<button className="reject-btn">Reject</button>
      </div>
    </div>
  );
}

export default Approvals;