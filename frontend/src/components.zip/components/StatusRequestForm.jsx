import { useState } from "react";

function StatusRequestForm() {
  const [status, setStatus] = useState("Not Started");

  const handleRequest = () => {
    const request = {
      task: "Dashboard UI",
      requestedStatus: status,
      requestedBy: "Trainee",
    };

    localStorage.setItem(
      "statusRequest",
      JSON.stringify(request)
    );

    alert("Status Change Request Sent!");
  };

  return (
    <div>
      <select
        value={status}
        onChange={(e) => setStatus(e.target.value)}
      >
        <option>Not Started</option>
        <option>In Progress</option>
        <option>Completed</option>
      </select>

      <button onClick={handleRequest}>
        Request Status Change
      </button>
    </div>
  );
}

export default StatusRequestForm;